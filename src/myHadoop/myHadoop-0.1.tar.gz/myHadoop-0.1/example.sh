#!/bin/bash

#PBS -q batch
#PBS -N hadoop_job
#PBS -l nodes=4:ppn=1
#PBS -o hadoop_run.out
#PBS -e hadoop_run.err
#PBS -A baru-tro
#PBS -V
#PBS -M sriram@sdsc.edu
#PBS -m abe

# Set this to location of myHadoop on Triton
export MY_HADOOP_HOME="/home/srkrishnan/Software/myHadoop"

# Set this to the location of Hadoop on Triton
export HADOOP_HOME="/home/srkrishnan/Software/hadoop-0.20.2"

#### Set this to the directory where Hadoop configs should be generated
# Don't change the name of this variable (HADOOP_CONF_DIR) as it is
# required by Hadoop - all config files will be picked up from here
#
# Make sure that this is accessible to all nodes
export HADOOP_CONF_DIR="/home/srkrishnan/Software/myHadoop/config"

#### Set up the configuration
# Make sure number of nodes is the same as what you have requested from PBS
# usage: $MY_HADOOP_HOME/bin/configure.sh -h
echo "Set up the configurations for myHadoop"
#$MY_HADOOP_HOME/bin/configure.sh -n 4 -c $HADOOP_CONF_DIR
$MY_HADOOP_HOME/bin/configure.sh -n 4 -c $HADOOP_CONF_DIR -p -d /oasis/cloudstor-group/HDFS
echo

#### Format HDFS, if this is the first time or not a persistent instance
echo "Format HDFS"
$HADOOP_HOME/bin/hadoop --config $HADOOP_CONF_DIR namenode -format
echo

#### Start the Hadoop cluster
echo "Start all Hadoop daemons"
$HADOOP_HOME/bin/start-all.sh
#$HADOOP_HOME/bin/hadoop dfsadmin -safemode leave
echo

#### Run your jobs here
echo "Run some test Hadoop jobs"
$HADOOP_HOME/bin/hadoop --config $HADOOP_CONF_DIR dfs -mkdir Test
$HADOOP_HOME/bin/hadoop --config $HADOOP_CONF_DIR dfs -copyFromLocal ~/.bashrc Test
$HADOOP_HOME/bin/hadoop --config $HADOOP_CONF_DIR dfs -ls Test
$HADOOP_HOME/bin/hadoop --config $HADOOP_CONF_DIR jar $HADOOP_HOME/hadoop-0.20.2-examples.jar wordcount Test Test-Output
$HADOOP_HOME/bin/hadoop --config $HADOOP_CONF_DIR dfs -ls Test-Output
echo

#### Stop the Hadoop cluster
echo "Stop all Hadoop daemons"
$HADOOP_HOME/bin/stop-all.sh
echo

#### Clean up the working directories after job completion
echo "Clean up"
$MY_HADOOP_HOME/bin/cleanup.sh -n 4
echo
